public interface Desconto {
  public double aplicarDesconto(double mensalidade);
}